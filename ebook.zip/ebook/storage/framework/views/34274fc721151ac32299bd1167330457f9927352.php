
<?php $__env->startSection('title', 'Our Team'); ?>
<?php $__env->startSection('content'); ?>
 <h1>Our Team</h1>
 <p>Our team is consists of A, B and C.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\ebook\resources\views/team.blade.php ENDPATH**/ ?>