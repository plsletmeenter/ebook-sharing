<!--nav-bar-->
<ul>
 <li><a href="/about"> About</a> </li>
 <li><a href="/team"> Our Team</a></li>
 <li><a href="/services"> Services</a></li>
 </ul><?php /**PATH C:\Users\user\ebook\resources\views/nav.blade.php ENDPATH**/ ?>