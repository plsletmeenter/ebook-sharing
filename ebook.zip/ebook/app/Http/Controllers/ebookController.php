<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ebookController extends Controller
{
    public function about () {
        return view('about');
        }

          public function team () {
        return view('team');
        }

              public function services () {
        $services = array(
        'fault in our stars by john green',
        'bad blood by lorne sage',
        'Light by M John Harrison (2002)',
        'Visitation by Jenny Erpenbeck (2008), translated by Susan Bernofsky (2010)'
        );
        return view('services', compact('services'));
        } 
       
}
