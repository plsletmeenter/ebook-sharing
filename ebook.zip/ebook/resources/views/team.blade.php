@extends('app')
@section('title', 'Our Team')
@section('content')
 <h1>Our Team</h1>
 <p>Our team is consists of A, B and C.</p>
@endsection