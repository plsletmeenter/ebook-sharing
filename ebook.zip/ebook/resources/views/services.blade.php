@extends('app')
@section('title', 'Services')
@section('content')
 <h1>List of Ebooks</h1>
 <ul>
 @foreach($services as $service)
 <li>{{ $service }} </li>
 @endforeach
 </ul>
@endsection 