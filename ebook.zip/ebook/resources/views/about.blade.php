@extends('app')
@section('title', 'About Us')
@section('content')
 <h1>About Ebook</h1>
 <p>There are plenty of advantages to eBooks–portability, accessibility, cloud-synced annotation–but there are a number of things that they don’t do nearly as well as print books. 
 Until recently, one of the most significant disadvantages was the inability to lend and borrow them. If you wanted to share a book from your digital library, you’d either have to 
 hand over your precious digital tablet for days or weeks, or resort to pirated files with no copy restriction. Amazon recently changed that, allowing users to share selected Kindle
  books from their library for a 14 day period. This is great if you have a number of friends and acquaintances with interesting Kindle libraries, but doesn’t really tap into the 
  Internet’s ability to connect strangers with shared interests. A number of enterprising developers quickly identified this opportunity, and have built matchmaking services that 
  connect eBook borrowers with lenders..
  Amazon’s take on these sharing services is ambiguous at this time–the company briefly revoked API access for one of them, Lendle, earlier in the week.
   Amazon has since reinstated Lendle’s access, but the incident serves as a reminder that such services are at the mercy of Amazon’s policies. 
For the time-being, however, this a great way for Kindle users to engage in some good old-fashioned book lending.
  </p>
@endsection 